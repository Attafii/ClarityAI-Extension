/**
 * Default configuration for ClarityAI extension
 */
export const DEFAULT_CONFIG = {
    // This points to your Cloudflare Worker proxy
    PROXY_URL: 'https://clarityai-proxy.attafiahmed-dev.workers.dev',
    // A shared secret between the extension and your proxy to prevent unauthorized use
    PROXY_TOKEN: 'clarityai-secure-handshake-2026'
};
